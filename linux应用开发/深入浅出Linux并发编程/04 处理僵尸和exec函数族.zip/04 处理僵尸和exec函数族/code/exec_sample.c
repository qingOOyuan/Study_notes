#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <errno.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	printf("[%d]\n", __LINE__);

	pid_t pid = fork();
	if(pid > 0)
	{
		printf("(parent) PID: %d, PPID: %d\n", getpid(), getppid());

		int status;
		waitpid(pid, &status, WNOHANG);

		printf("child exit code: %d\n", WEXITSTATUS(status));
	}

	if(pid == 0)
	{
		//execl("./child_process", "./child_process", "abcd", NULL);

		char *arg[] = {"./child_process", "abcd", NULL};
		execv("./child_process", arg);

		//execl("/bin/ls", "ls", "-l", NULL);
		//execlp("ls", "ls", "-l", NULL);

		printf("xxxx\n");
	}

	return 0;
}
