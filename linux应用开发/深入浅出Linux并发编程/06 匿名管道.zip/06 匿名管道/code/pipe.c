#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <errno.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	int fd[2];

	pipe(fd); // fd[0] for reading, fd[1] for writting

	pid_t pid = fork();

	// parent
	if(pid > 0)
	{
		char buf[100];
		bzero(buf, 100);
		read(fd[0], buf, 100);
		printf("from child: %s\n", buf);
	}

	// child
	else if(pid == 0)
	{
		sleep(2);
		char *msg = "hey! dad!";
		write(fd[1], msg, strlen(msg));
	}

	return 0;
}
