#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <errno.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int a = 100;

int main(int argc, char **argv)
{
	int b = 200;
	printf("[%d]\n", __LINE__);

	int *p = malloc(sizeof(int));
	*p = 300;

	pid_t pid = fork();

	if(pid > 0) // parent
	{
		sleep(1);
		printf("[parent]*a: %d\n", a);
		printf("[parent]*b: %d\n", b);
		printf("[parent]*p: %d\n", *p);
	}

	if(pid == 0) // child
	{
		a = 1000;
		b = 2000;
		*p = 3000;
		printf("[child]a: %d\n", a);
		printf("[child]b: %d\n", b);
		printf("[child]*p: %d\n", *p);
	}


	printf("[%d]\n", __LINE__);

	return 0;
}
