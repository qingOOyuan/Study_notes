#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <errno.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

void f1(void)
{
	printf("[%s] is calling...\n", __FUNCTION__);
}

void f2(void)
{
	printf("[%s] is calling...\n", __FUNCTION__);
}

int main(int argc, char **argv)
{
	atexit(f1);
	atexit(f2);

	printf("abcd");

	_exit(0);
	exit(0);
}
