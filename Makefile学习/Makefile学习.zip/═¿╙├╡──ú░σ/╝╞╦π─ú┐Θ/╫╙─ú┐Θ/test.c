#include <stdio.h>
#include <test.h>

void test(void)
{
	printf("我是test\n");

}