#ifndef _PRINT_HELLO_H_
#define _PRINT_HELLO_H_

void print_hello(void);


#endif