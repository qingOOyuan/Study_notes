#ifndef _CALC_H_
#define _CALC_H_

int calc(int n);

#endif