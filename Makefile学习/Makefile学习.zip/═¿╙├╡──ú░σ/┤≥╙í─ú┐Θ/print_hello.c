#include <stdio.h>
#include <print_hello.h>

void print_hello(void)
{
	int i;
	printf("hello world!\n");
}