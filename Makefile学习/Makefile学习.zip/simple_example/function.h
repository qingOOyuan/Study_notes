#ifndef _FUNCTION_H_
#define _FUNCTION_H_

void print_hello(void);
int calc(int n);

#endif