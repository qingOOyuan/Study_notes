#include "function.h"
#include <stdio.h>

void print_hello(void)
{
	int i;
	printf("hello world!\n");
}